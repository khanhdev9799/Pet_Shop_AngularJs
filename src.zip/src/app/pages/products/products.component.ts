import { Component } from '@angular/core';
import { product } from 'src/app/pages/models/product.model';
import { cart } from '../models/cart.model';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.scss']
})
export class ProductsComponent {

  showInvoice: boolean = false;
  products: product[] =[
    {
      id:1,
      name: 'qưe',
      image: 'trung',
      price: 30000,
      type: 'abc',
      stock: 10,
    },
    {
      id:2,
      name: 'abc',
      image: 'trung',
      price: 30000,
      type: 'abc',
      stock: 10,
    },
    {
      id:3,
      name: 'abc',
      image: 'trung',
      price: 30000,
      type: 'abc',
      stock: 10,
    },
    {
      id:4,
      name: 'abc',
      image: 'trung',
      price: 30000,
      type: 'abc',
      stock: 10,
    },
    {
      id:5,
      name: 'abc',
      image: 'trung',
      price: 30000,
      type: 'abc',
      stock: 10,
    },
    {
      id:6,
      name: 'abc',
      image: 'trung',
      price: 30000,
      type: 'abc',
      stock: 10,
    },
    {
      id:7,
      name: 'abc',
      image: 'trung',
      price: 30000,
      type: 'abc',
      stock: 10,
    },
    {
      id:8,
      name: 'abc',
      image: 'trung',
      price: 30000,
      type: 'abc',
      stock: 10,
    },
    {
      id:9,
      name: 'abc',
      image: 'trung',
      price: 30000,
      type: 'abc',
      stock: 10,
    },
    {
      id:10,
      name: 'abc',
      image: 'trung',
      price: 30000,
      type: 'abc',
      stock: 10,
    },
    {
      id:11,
      name: 'abc',
      image: 'trung',
      price: 30000,
      type: 'abc',
      stock: 10,
    },
    {
      id:12,
      name: 'abc',
      image: 'trung',
      price: 30000,
      type: 'abc',
      stock: 10,
    },
  ];

  carts: cart[]=[];
  total: number=0

  // Thêm sản phẩm vào giỏ hàng
  addToCart(product: product) {
    const existingItem = this.carts.find(item => item.id === product.id);

    if (existingItem) {
      existingItem.quantity++;
      product
    } else {
      this.carts.push({
        id: product.id,
        name: product.name,
        image: product.image,
        price: product.price,
        type: product.type,
        quantity: 1
      });
    }
    const productIndex = this.products.findIndex(p => p.id === product.id);
    if (productIndex !== -1) {
      this.products[productIndex].stock--; // Giảm số lượng tồn kho
    }
    this.outProducts(this.products[productIndex].stock,this.products[productIndex].name);
    this.calculateTotal();
  }

  // Tính tổng giá trị của giỏ hàng
  calculateTotal() {
    this.total = this.carts.reduce((acc, curr) => acc + (curr.price * curr.quantity), 0);
  }
  onConfirm() {
    // Hiển thị hóa đơn khi nút "Confirm" được nhấn
    this.showInvoice = true;
  }
  closeInvoice() {
    this.showInvoice = false;
  }

  isOutOfStock(item: any): boolean {
    const product = this.products.find(p => p.id === item.id);
    return product ? product.stock === 0 : true;
  }
  increaseQuantity(item: cart) {
    const productIndex = this.products.findIndex(p => p.id === item.id);
    if (productIndex !== -1 && this.products[productIndex].stock>0) {
      item.quantity++;
      this.products[productIndex].stock--; // Giảm số lượng tồn kho
    }
    this.outProducts(this.products[productIndex].stock,this.products[productIndex].name);
  }
  outProducts(stock: any,name:any){
    if(stock===0){
      alert(name +' hết hàng');
    }

  }

  decreaseQuantity(item: cart) {
    const productIndex = this.products.findIndex(p => p.id === item.id);
    const cartIndex = this.carts.findIndex(c => c.id === item.id);
    if (productIndex !== -1 && item.quantity > 0) {
      item.quantity--;
      this.products[productIndex].stock++; // Tăng số lượng tồn kho
      this.calculateTotal();
    }
    if(item.quantity === 0){
      this.carts.splice(cartIndex, 1);
      console.log(item.id);
    }
  }

  invoice(){
    this.carts=[];
    this.total = 0;
    this.showInvoice = false;
  }
  
}
