import { Component } from '@angular/core';
import { product } from '../models/product.model';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.scss']
})
export class ProductListComponent {
  isForm: boolean =false;
  products: product[] =[
    {
      id:1,
      name: 'abc',
      image: 'trung',
      price: 30000,
      type: 'abc',
      stock: 100,
    },
    {
      id:1,
      name: 'abc',
      image: 'trung',
      price: 30000,
      type: 'abc',
      stock: 100,
    },
    {
      id:1,
      name: 'abc',
      image: 'trung',
      price: 30000,
      type: 'abc',
      stock: 100,
    },
    {
      id:1,
      name: 'abc',
      image: 'trung',
      price: 30000,
      type: 'abc',
      stock: 100,
    },
    {
      id:1,
      name: 'abc',
      image: 'trung',
      price: 30000,
      type: 'abc',
      stock: 100,
    },
    {
      id:1,
      name: 'abc',
      image: 'trung',
      price: 30000,
      type: 'abc',
      stock: 100,
    },
    {
      id:1,
      name: 'abc',
      image: 'trung',
      price: 30000,
      type: 'abc',
      stock: 100,
    },
    {
      id:1,
      name: 'abc',
      image: 'trung',
      price: 30000,
      type: 'abc',
      stock: 100,
    },
    {
      id:1,
      name: 'abc',
      image: 'trung',
      price: 30000,
      type: 'abc',
      stock: 100,
    },
    {
      id:1,
      name: 'abc',
      image: 'trung',
      price: 30000,
      type: 'abc',
      stock: 100,
    },
    {
      id:1,
      name: 'abc',
      image: 'trung',
      price: 30000,
      type: 'abc',
      stock: 100,
    },
    {
      id:1,
      name: 'abc',
      image: 'trung',
      price: 30000,
      type: 'abc',
      stock: 100,
    },
  ];
  newProduct: product = new product();
  toggleForm(){
    this.isForm =! this.isForm;
  }

  // Thêm sản phẩm mới
  addProduct(newProduct: product) {
    this.products.push(newProduct);
  }

  // Xoá sản phẩm
  deleteProduct(id: number) {
    this.products = this.products.filter(product => product.id !== id);
  }

  // Chỉnh sửa sản phẩm
  editProduct(updatedProduct: product) {
    this.products = this.products.map(product => {
      if (product.id === updatedProduct.id) {
        return updatedProduct;
      }
      return product;
    });
  }
}
