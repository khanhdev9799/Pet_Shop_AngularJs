export class product{
    id: number=-1;
    name: string='';
    image: string='';
    price: number=-1;
    type: string='';
    stock: number=-1;
}