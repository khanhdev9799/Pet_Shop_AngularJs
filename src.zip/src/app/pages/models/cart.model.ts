export class cart{
    id: number=-1;
    name: string='';
    image: string='';
    price: number=-1;
    type: string='';
    quantity: number=-1;
}